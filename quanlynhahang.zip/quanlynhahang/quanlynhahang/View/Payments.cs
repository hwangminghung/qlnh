﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace quanlynhahang.View
{
    public partial class Payments : Form
    {
        SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=qlnh;Integrated Security=True");

        public Payments()
        {
            InitializeComponent();
        }
        private void HienThiPayment()
        {
            SqlCommand cmd = new SqlCommand("select * from Payments", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dgv_payment.DataSource = dt;
        }
        private void Payments_Load(object sender, EventArgs e)
        {
            HienThiPayment();
        }

        private void btn_add_Click(object sender, EventArgs e)
        {

            if (string.IsNullOrEmpty(txt_paymentid.Text) || string.IsNullOrEmpty(txt_orderid.Text) ||
        string.IsNullOrEmpty(txt_amount.Text))
            {
                MessageBox.Show("Xin hãy điền đầy đủ thông tin trước khi thêm");
            }
            else
            {
                SqlDataAdapter da = new SqlDataAdapter("select PaymentID from Payments where PaymentID = '" + txt_paymentid.Text + "'", con);
                DataTable dt = new DataTable();
                da.Fill(dt);

                if (dt.Rows.Count >= 1)
                {
                    MessageBox.Show("Trùng mã ID !");
                }
                else
                {
                    string query = "insert into Payments values('" + txt_paymentid.Text + "',N'" + txt_orderid.Text + "','" + txt_amount.Text + "','" + dtp_payment.Value.ToString("yyyy/MM/dd hh:mm") + "' )";
                    SqlCommand cmd = new SqlCommand(query, con);

                    con.Open();
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Thêm thành công");
                    con.Close();

                    HienThiPayment();
                }
            }
        }

        private void btn_update_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txt_paymentid.Text) || string.IsNullOrEmpty(txt_orderid.Text) ||
 string.IsNullOrEmpty(txt_amount.Text))
            {
                MessageBox.Show("Xin hãy chọn đối tượng cần sửa");
            }
            else
            {
                try
                {
                    string query = "update Payments set PaymentID='" + txt_paymentid.Text + "',OrderID=N'" + txt_orderid.Text + "',AmountPaid='" + txt_amount.Text + "',PaymentDate='" + dtp_payment.Value.ToString("yyyy,MM,dd hh:mm") + "' where PaymentID='" + dgv_payment.CurrentRow.Cells[0].Value + "'";

                    SqlCommand cmd = new SqlCommand(query, con);

                    con.Open();
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Sửa thành công");
                    con.Close();
                    btn_reset.PerformClick();

                    HienThiPayment();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txt_paymentid.Text) || string.IsNullOrEmpty(txt_orderid.Text) ||
   string.IsNullOrEmpty(txt_amount.Text))
            {
                MessageBox.Show("Xin hãy chọn đối tượng cần xoá");
            }
            else
            {
                try
                {
                    string query = "delete from Payments where PaymentID=@paymentid";
                    SqlCommand command = new SqlCommand(query, con);
                    command.Parameters.AddWithValue("@paymentid", txt_paymentid.Text);

                    con.Open();
                    command.ExecuteNonQuery();
                    MessageBox.Show("Xoá Thành Công");
                    txt_amount.Text = string.Empty;
                    txt_paymentid.Text = string.Empty;
                    txt_orderid.Text = string.Empty;
                    con.Close();

                    HienThiPayment();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void dgv_payment_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            txt_paymentid.Text = dgv_payment.CurrentRow.Cells[0].Value.ToString();
            txt_orderid.Text = dgv_payment.CurrentRow.Cells[1].Value.ToString();
            txt_amount.Text = dgv_payment.CurrentRow.Cells[2].Value.ToString();
            dtp_payment.Value = (DateTime)dgv_payment.CurrentRow.Cells[3].Value;
        }

        private void btn_reset_Click(object sender, EventArgs e)
        {
            txt_amount.Text = string.Empty;
            txt_orderid.Text = string.Empty;
            txt_paymentid.Text = string.Empty;
        }
        private DataTable TimKiem()
        {
            string queryTimKiem = "select * from Payments ";
            queryTimKiem += "where PaymentID Like '%' + @timkiem + '%'";
            queryTimKiem += "or OrderID Like '%' + @timkiem + '%'";
            queryTimKiem += "or AmountPaid Like '%' + @timkiem + '%'";
            queryTimKiem += "or PaymentDate Like '%' + @timkiem + '%'";

            SqlCommand command = new SqlCommand(queryTimKiem, con);
            command.Parameters.AddWithValue("@timkiem", txt_search.Text);

            SqlDataAdapter da = new SqlDataAdapter(command);
            DataTable dt = new DataTable();
            da.Fill(dt);

            dgv_payment.DataSource = dt;

            con.Close(); // Lưu ý: Dòng này sẽ không được thực hiện vì đã có return trước đó

            return dt;
        }
        private void txt_search_TextChanged(object sender, EventArgs e)
        {
            dgv_payment.DataSource = TimKiem();

        }
    }
}
