﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace quanlynhahang.View
{
    public partial class orderdetail : Form
    {
        SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=qlnh;Integrated Security=True");

        public orderdetail()
        {
            InitializeComponent();
        }
        private void HienThiOrderDetail()
        {
            SqlCommand cmd = new SqlCommand("select * from OrderDetails", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dgv_orderdetail.DataSource = dt;
        }
        private void orderdetail_Load(object sender, EventArgs e)
        {
            HienThiOrderDetail();
        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txt_itemid.Text) || string.IsNullOrEmpty(txt_orderid.Text) ||
       string.IsNullOrEmpty(txt_orderdetailid.Text))
            {
                MessageBox.Show("Xin hãy điền đầy đủ thông tin trước khi thêm");
            }
            else
            {
                SqlDataAdapter da = new SqlDataAdapter("select OrderDetailID from OrderDetails where OrderDetailID = '" + txt_orderdetailid.Text + "'", con);
                DataTable dt = new DataTable();
                da.Fill(dt);

                if (dt.Rows.Count >= 1)
                {
                    MessageBox.Show("Trùng mã ID !");
                }
                else
                {
                    string query = "insert into OrderDetails values('" + txt_orderdetailid.Text + "',N'" + txt_orderid.Text + "','" + txt_itemid.Text + "','" + txt_quantityid.Text + "' )";
                    SqlCommand cmd = new SqlCommand(query, con);

                    con.Open();
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Thêm thành công");
                    con.Close();

                    HienThiOrderDetail();
                }
            }
        }

        private void btn_update_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txt_itemid.Text) || string.IsNullOrEmpty(txt_orderdetailid.Text) ||
 string.IsNullOrEmpty(txt_orderid.Text))
            {
                MessageBox.Show("Xin hãy chọn đối tượng cần sửa");
            }
            else
            {
                try
                {
                    string query = "update OrderDetails set OrderDetailID='" + txt_orderdetailid.Text + "',OrderID=N'" + txt_orderid.Text + "',Quantity='" + txt_quantityid.Text + "' where OrderID='" + dgv_orderdetail.CurrentRow.Cells[0].Value + "'";

                    SqlCommand cmd = new SqlCommand(query, con);

                    con.Open();
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Sửa thành công");
                    con.Close();
                    btn_reset.PerformClick();

                    HienThiOrderDetail();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txt_orderdetailid.Text) || string.IsNullOrEmpty(txt_orderid.Text) ||
  string.IsNullOrEmpty(txt_itemid.Text))
            {
                MessageBox.Show("Xin hãy chọn đối tượng cần xoá");
            }
            else
            {
                try
                {
                    string query = "delete from OrderDetails where OrderDetailID=@modt";
                    SqlCommand command = new SqlCommand(query, con);
                    command.Parameters.AddWithValue("@modt", txt_orderdetailid.Text);

                    con.Open();
                    command.ExecuteNonQuery();
                    MessageBox.Show("Xoá Thành Công");
                    txt_orderdetailid.Text = string.Empty;
                    txt_itemid.Text = string.Empty;
                    txt_orderid.Text = string.Empty;
                    txt_quantityid.Text = string.Empty;

                    con.Close();

                    HienThiOrderDetail();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void btn_reset_Click(object sender, EventArgs e)
        {
            txt_itemid.Text= string.Empty;
            txt_orderdetailid.Text= string.Empty;
            txt_orderid.Text    = string.Empty;
            txt_quantityid.Text = string.Empty;
        }

        private void dgv_orderdetail_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            txt_orderdetailid.Text = dgv_orderdetail.CurrentRow.Cells[0].Value.ToString();
            txt_orderid.Text = dgv_orderdetail.CurrentRow.Cells[1].Value.ToString();
            txt_itemid.Text = dgv_orderdetail.CurrentRow.Cells[2].Value.ToString();
            txt_quantityid.Text = dgv_orderdetail.CurrentRow.Cells[3].Value.ToString();
        }
        private DataTable TimKiem()
        {
            string queryTimKiem = "select * from OrderDetails ";
            queryTimKiem += "where OrderDetailID Like '%' + @timkiem + '%'";
            queryTimKiem += "or OrderID Like '%' + @timkiem + '%'";
            queryTimKiem += "or ItemID Like '%' + @timkiem + '%'";
            queryTimKiem += "or Quantity Like '%' + @timkiem + '%'";

            SqlCommand command = new SqlCommand(queryTimKiem, con);
            command.Parameters.AddWithValue("@timkiem", txt_search.Text);

            SqlDataAdapter da = new SqlDataAdapter(command);
            DataTable dt = new DataTable();
            da.Fill(dt);

            dgv_orderdetail.DataSource = dt;

            con.Close(); // Lưu ý: Dòng này sẽ không được thực hiện vì đã có return trước đó

            return dt;
        }

        private void txt_search_TextChanged(object sender, EventArgs e)
        {
            dgv_orderdetail.DataSource = TimKiem();
        }
    }
}
