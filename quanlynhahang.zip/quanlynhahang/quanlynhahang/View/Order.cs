﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace quanlynhahang.View
{
    public partial class Order : Form
    {
        SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=qlnh;Integrated Security=True");

        public Order()
        {
            InitializeComponent();
        }
        private void HienThiOrder()
        {
            SqlCommand cmd = new SqlCommand("select * from Orders", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dgv_order.DataSource = dt;
        }
        private void Order_Load(object sender, EventArgs e)
        {
            HienThiOrder();
        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txt_customerid.Text) || string.IsNullOrEmpty(txt_orderid.Text) ||
        string.IsNullOrEmpty(txt_tableid.Text))
            {
                MessageBox.Show("Xin hãy điền đầy đủ thông tin trước khi thêm");
            }
            else
            {
                SqlDataAdapter da = new SqlDataAdapter("select OrderID from Orders where OrderID = '" + txt_orderid.Text + "'", con);
                DataTable dt = new DataTable();
                da.Fill(dt);

                if (dt.Rows.Count >= 1)
                {
                    MessageBox.Show("Trùng mã ID !");
                }
                else
                {
                    string query = "insert into Orders values('" + txt_orderid.Text + "',N'" + txt_customerid.Text + "','" + txt_tableid.Text + "','"+dtp_orderdate.Value.ToString("yyyy/MM/dd hh:mm")+"' )";
                    SqlCommand cmd = new SqlCommand(query, con);

                    con.Open();
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Thêm thành công");
                    con.Close();

                    HienThiOrder();
                }
            }
        }

        private void btn_update_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txt_tableid.Text) || string.IsNullOrEmpty(txt_customerid.Text) ||
  string.IsNullOrEmpty(txt_orderid.Text))
            {
                MessageBox.Show("Xin hãy chọn đối tượng cần sửa");
            }
            else
            {
                try
                {
                    string query = "update Orders set OrderID='" + txt_orderid.Text + "',CustomerID=N'" + txt_customerid.Text + "',TableID='" + txt_tableid.Text + "',OrderDate='"+dtp_orderdate.Value.ToString("yyyy,MM,dd hh:mm")+"' where OrderID='" + dgv_order.CurrentRow.Cells[0].Value + "'";

                    SqlCommand cmd = new SqlCommand(query, con);

                    con.Open();
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Sửa thành công");
                    con.Close();
                    btn_reset.PerformClick();

                    HienThiOrder();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void dgv_order_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            txt_orderid.Text = dgv_order.CurrentRow.Cells[0].Value.ToString();
            txt_customerid.Text = dgv_order.CurrentRow.Cells[1].Value.ToString();
            txt_tableid.Text = dgv_order.CurrentRow.Cells[2].Value.ToString();
            dtp_orderdate.Value = (DateTime)dgv_order.CurrentRow.Cells[3].Value;
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txt_tableid.Text) || string.IsNullOrEmpty(txt_orderid.Text) ||
   string.IsNullOrEmpty(txt_customerid.Text))
            {
                MessageBox.Show("Xin hãy chọn đối tượng cần xoá");
            }
            else
            {
                try
                {
                    string query = "delete from Orders where OrderID=@mod";
                    SqlCommand command = new SqlCommand(query, con);
                    command.Parameters.AddWithValue("@mod", txt_tableid.Text);

                    con.Open();
                    command.ExecuteNonQuery();
                    MessageBox.Show("Xoá Thành Công");
                    txt_tableid.Text = string.Empty;
                    txt_customerid.Text = string.Empty;
                    txt_orderid.Text = string.Empty;
                    con.Close();

                    HienThiOrder();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void btn_reset_Click(object sender, EventArgs e)
        {
            txt_orderid.Text = string.Empty;
            txt_tableid.Text= string.Empty;
            txt_customerid.Text= string.Empty;
        }
        private DataTable TimKiem()
        {
            string queryTimKiem = "select * from Orders ";
            queryTimKiem += "where OrderID Like '%' + @timkiem + '%'";
            queryTimKiem += "or CustomerID Like '%' + @timkiem + '%'";
            queryTimKiem += "or TableID Like '%' + @timkiem + '%'"; 
            queryTimKiem += "or OrderDate Like '%' + @timkiem + '%'";

            SqlCommand command = new SqlCommand(queryTimKiem, con);
            command.Parameters.AddWithValue("@timkiem", txt_search.Text);

            SqlDataAdapter da = new SqlDataAdapter(command);
            DataTable dt = new DataTable();
            da.Fill(dt);

            dgv_order.DataSource = dt;

            con.Close(); // Lưu ý: Dòng này sẽ không được thực hiện vì đã có return trước đó

            return dt;
        }

        private void txt_search_TextChanged(object sender, EventArgs e)
        {
            dgv_order.DataSource = TimKiem();
        }

        private void gunaPictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
