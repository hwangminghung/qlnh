﻿namespace quanlynhahang
{
    partial class Menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Menu));
            this.centerpanel = new Guna.UI.WinForms.GunaPanel();
            this.gunaPanel2 = new Guna.UI.WinForms.GunaPanel();
            this.gunaLabel1 = new Guna.UI.WinForms.GunaLabel();
            this.gunaPanel3 = new Guna.UI.WinForms.GunaPanel();
            this.gunaControlBox3 = new Guna.UI.WinForms.GunaControlBox();
            this.gunaControlBox2 = new Guna.UI.WinForms.GunaControlBox();
            this.gunaControlBox1 = new Guna.UI.WinForms.GunaControlBox();
            this.btn_payment = new Guna.UI.WinForms.GunaButton();
            this.btn_pos = new Guna.UI.WinForms.GunaButton();
            this.btn_order = new Guna.UI.WinForms.GunaButton();
            this.btn_table = new Guna.UI.WinForms.GunaButton();
            this.btn_item = new Guna.UI.WinForms.GunaButton();
            this.btn_customer = new Guna.UI.WinForms.GunaButton();
            this.gunaPictureBox1 = new Guna.UI.WinForms.GunaPictureBox();
            this.gunaPictureBox2 = new Guna.UI.WinForms.GunaPictureBox();
            this.gunaElipse1 = new Guna.UI.WinForms.GunaElipse(this.components);
            this.gunaAnimateWindow1 = new Guna.UI.WinForms.GunaAnimateWindow(this.components);
            this.centerpanel.SuspendLayout();
            this.gunaPanel2.SuspendLayout();
            this.gunaPanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // centerpanel
            // 
            this.centerpanel.Controls.Add(this.gunaPictureBox2);
            this.centerpanel.Location = new System.Drawing.Point(200, 48);
            this.centerpanel.Name = "centerpanel";
            this.centerpanel.Size = new System.Drawing.Size(952, 620);
            this.centerpanel.TabIndex = 0;
            this.centerpanel.Paint += new System.Windows.Forms.PaintEventHandler(this.centerpanel_Paint);
            // 
            // gunaPanel2
            // 
            this.gunaPanel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.gunaPanel2.Controls.Add(this.btn_payment);
            this.gunaPanel2.Controls.Add(this.btn_pos);
            this.gunaPanel2.Controls.Add(this.btn_order);
            this.gunaPanel2.Controls.Add(this.btn_table);
            this.gunaPanel2.Controls.Add(this.btn_item);
            this.gunaPanel2.Controls.Add(this.btn_customer);
            this.gunaPanel2.Controls.Add(this.gunaLabel1);
            this.gunaPanel2.Controls.Add(this.gunaPictureBox1);
            this.gunaPanel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.gunaPanel2.Location = new System.Drawing.Point(0, 0);
            this.gunaPanel2.Name = "gunaPanel2";
            this.gunaPanel2.Size = new System.Drawing.Size(200, 668);
            this.gunaPanel2.TabIndex = 0;
            this.gunaPanel2.Paint += new System.Windows.Forms.PaintEventHandler(this.gunaPanel2_Paint);
            // 
            // gunaLabel1
            // 
            this.gunaLabel1.AutoSize = true;
            this.gunaLabel1.Font = new System.Drawing.Font("Viner Hand ITC", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gunaLabel1.Location = new System.Drawing.Point(3, 146);
            this.gunaLabel1.Name = "gunaLabel1";
            this.gunaLabel1.Size = new System.Drawing.Size(195, 26);
            this.gunaLabel1.TabIndex = 1;
            this.gunaLabel1.Text = "Nhà hàng 5 sao me che le";
            // 
            // gunaPanel3
            // 
            this.gunaPanel3.Controls.Add(this.gunaControlBox3);
            this.gunaPanel3.Controls.Add(this.gunaControlBox2);
            this.gunaPanel3.Controls.Add(this.gunaControlBox1);
            this.gunaPanel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.gunaPanel3.Location = new System.Drawing.Point(200, 0);
            this.gunaPanel3.Name = "gunaPanel3";
            this.gunaPanel3.Size = new System.Drawing.Size(952, 49);
            this.gunaPanel3.TabIndex = 0;
            // 
            // gunaControlBox3
            // 
            this.gunaControlBox3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.gunaControlBox3.AnimationHoverSpeed = 0.07F;
            this.gunaControlBox3.AnimationSpeed = 0.03F;
            this.gunaControlBox3.ControlBoxType = Guna.UI.WinForms.FormControlBoxType.MinimizeBox;
            this.gunaControlBox3.IconColor = System.Drawing.Color.Black;
            this.gunaControlBox3.IconSize = 15F;
            this.gunaControlBox3.Location = new System.Drawing.Point(778, 13);
            this.gunaControlBox3.Name = "gunaControlBox3";
            this.gunaControlBox3.OnHoverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(58)))), ((int)(((byte)(183)))));
            this.gunaControlBox3.OnHoverIconColor = System.Drawing.Color.White;
            this.gunaControlBox3.OnPressedColor = System.Drawing.Color.Black;
            this.gunaControlBox3.Size = new System.Drawing.Size(45, 29);
            this.gunaControlBox3.TabIndex = 0;
            // 
            // gunaControlBox2
            // 
            this.gunaControlBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.gunaControlBox2.AnimationHoverSpeed = 0.07F;
            this.gunaControlBox2.AnimationSpeed = 0.03F;
            this.gunaControlBox2.ControlBoxType = Guna.UI.WinForms.FormControlBoxType.MaximizeBox;
            this.gunaControlBox2.IconColor = System.Drawing.Color.Black;
            this.gunaControlBox2.IconSize = 15F;
            this.gunaControlBox2.Location = new System.Drawing.Point(829, 13);
            this.gunaControlBox2.Name = "gunaControlBox2";
            this.gunaControlBox2.OnHoverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(58)))), ((int)(((byte)(183)))));
            this.gunaControlBox2.OnHoverIconColor = System.Drawing.Color.White;
            this.gunaControlBox2.OnPressedColor = System.Drawing.Color.Black;
            this.gunaControlBox2.Size = new System.Drawing.Size(45, 29);
            this.gunaControlBox2.TabIndex = 0;
            // 
            // gunaControlBox1
            // 
            this.gunaControlBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.gunaControlBox1.AnimationHoverSpeed = 0.07F;
            this.gunaControlBox1.AnimationSpeed = 0.03F;
            this.gunaControlBox1.IconColor = System.Drawing.Color.Black;
            this.gunaControlBox1.IconSize = 15F;
            this.gunaControlBox1.Location = new System.Drawing.Point(892, 13);
            this.gunaControlBox1.Name = "gunaControlBox1";
            this.gunaControlBox1.OnHoverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(58)))), ((int)(((byte)(183)))));
            this.gunaControlBox1.OnHoverIconColor = System.Drawing.Color.White;
            this.gunaControlBox1.OnPressedColor = System.Drawing.Color.Black;
            this.gunaControlBox1.Size = new System.Drawing.Size(45, 29);
            this.gunaControlBox1.TabIndex = 0;
            // 
            // btn_payment
            // 
            this.btn_payment.AnimationHoverSpeed = 0.07F;
            this.btn_payment.AnimationSpeed = 0.03F;
            this.btn_payment.BaseColor = System.Drawing.Color.Transparent;
            this.btn_payment.BorderColor = System.Drawing.Color.Black;
            this.btn_payment.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btn_payment.FocusedColor = System.Drawing.Color.Empty;
            this.btn_payment.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_payment.ForeColor = System.Drawing.Color.White;
            this.btn_payment.Image = ((System.Drawing.Image)(resources.GetObject("btn_payment.Image")));
            this.btn_payment.ImageSize = new System.Drawing.Size(20, 20);
            this.btn_payment.Location = new System.Drawing.Point(21, 578);
            this.btn_payment.Name = "btn_payment";
            this.btn_payment.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btn_payment.OnHoverBorderColor = System.Drawing.Color.Black;
            this.btn_payment.OnHoverForeColor = System.Drawing.Color.White;
            this.btn_payment.OnHoverImage = null;
            this.btn_payment.OnPressedColor = System.Drawing.Color.Black;
            this.btn_payment.Size = new System.Drawing.Size(160, 42);
            this.btn_payment.TabIndex = 2;
            this.btn_payment.Text = "Payment";
            this.btn_payment.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btn_payment.Click += new System.EventHandler(this.btn_payment_Click);
            // 
            // btn_pos
            // 
            this.btn_pos.AnimationHoverSpeed = 0.07F;
            this.btn_pos.AnimationSpeed = 0.03F;
            this.btn_pos.BaseColor = System.Drawing.Color.Transparent;
            this.btn_pos.BorderColor = System.Drawing.Color.Black;
            this.btn_pos.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btn_pos.FocusedColor = System.Drawing.Color.Empty;
            this.btn_pos.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_pos.ForeColor = System.Drawing.Color.White;
            this.btn_pos.Image = ((System.Drawing.Image)(resources.GetObject("btn_pos.Image")));
            this.btn_pos.ImageSize = new System.Drawing.Size(20, 20);
            this.btn_pos.Location = new System.Drawing.Point(21, 495);
            this.btn_pos.Name = "btn_pos";
            this.btn_pos.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.btn_pos.OnHoverBorderColor = System.Drawing.Color.Black;
            this.btn_pos.OnHoverForeColor = System.Drawing.Color.White;
            this.btn_pos.OnHoverImage = null;
            this.btn_pos.OnPressedColor = System.Drawing.Color.Black;
            this.btn_pos.Size = new System.Drawing.Size(160, 42);
            this.btn_pos.TabIndex = 2;
            this.btn_pos.Text = "OrderDetail";
            this.btn_pos.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btn_pos.Click += new System.EventHandler(this.btn_pos_Click);
            // 
            // btn_order
            // 
            this.btn_order.AnimationHoverSpeed = 0.07F;
            this.btn_order.AnimationSpeed = 0.03F;
            this.btn_order.BaseColor = System.Drawing.Color.Transparent;
            this.btn_order.BorderColor = System.Drawing.Color.Black;
            this.btn_order.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btn_order.FocusedColor = System.Drawing.Color.Empty;
            this.btn_order.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_order.ForeColor = System.Drawing.Color.White;
            this.btn_order.Image = ((System.Drawing.Image)(resources.GetObject("btn_order.Image")));
            this.btn_order.ImageSize = new System.Drawing.Size(20, 20);
            this.btn_order.Location = new System.Drawing.Point(21, 427);
            this.btn_order.Name = "btn_order";
            this.btn_order.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.btn_order.OnHoverBorderColor = System.Drawing.Color.Black;
            this.btn_order.OnHoverForeColor = System.Drawing.Color.White;
            this.btn_order.OnHoverImage = null;
            this.btn_order.OnPressedColor = System.Drawing.Color.Black;
            this.btn_order.Size = new System.Drawing.Size(160, 42);
            this.btn_order.TabIndex = 2;
            this.btn_order.Text = "Order";
            this.btn_order.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btn_order.Click += new System.EventHandler(this.btn_order_Click);
            // 
            // btn_table
            // 
            this.btn_table.AnimationHoverSpeed = 0.07F;
            this.btn_table.AnimationSpeed = 0.03F;
            this.btn_table.BaseColor = System.Drawing.Color.Transparent;
            this.btn_table.BorderColor = System.Drawing.Color.Black;
            this.btn_table.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btn_table.FocusedColor = System.Drawing.Color.Empty;
            this.btn_table.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_table.ForeColor = System.Drawing.Color.White;
            this.btn_table.Image = ((System.Drawing.Image)(resources.GetObject("btn_table.Image")));
            this.btn_table.ImageSize = new System.Drawing.Size(20, 20);
            this.btn_table.Location = new System.Drawing.Point(21, 357);
            this.btn_table.Name = "btn_table";
            this.btn_table.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.btn_table.OnHoverBorderColor = System.Drawing.Color.Black;
            this.btn_table.OnHoverForeColor = System.Drawing.Color.White;
            this.btn_table.OnHoverImage = null;
            this.btn_table.OnPressedColor = System.Drawing.Color.Black;
            this.btn_table.Size = new System.Drawing.Size(160, 42);
            this.btn_table.TabIndex = 2;
            this.btn_table.Text = "Tables";
            this.btn_table.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btn_table.Click += new System.EventHandler(this.btn_table_Click);
            // 
            // btn_item
            // 
            this.btn_item.AnimationHoverSpeed = 0.07F;
            this.btn_item.AnimationSpeed = 0.03F;
            this.btn_item.BaseColor = System.Drawing.Color.Transparent;
            this.btn_item.BorderColor = System.Drawing.Color.Black;
            this.btn_item.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btn_item.FocusedColor = System.Drawing.Color.Empty;
            this.btn_item.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_item.ForeColor = System.Drawing.Color.White;
            this.btn_item.Image = ((System.Drawing.Image)(resources.GetObject("btn_item.Image")));
            this.btn_item.ImageSize = new System.Drawing.Size(20, 20);
            this.btn_item.Location = new System.Drawing.Point(21, 288);
            this.btn_item.Name = "btn_item";
            this.btn_item.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(143)))), ((int)(((byte)(255)))));
            this.btn_item.OnHoverBorderColor = System.Drawing.Color.Black;
            this.btn_item.OnHoverForeColor = System.Drawing.Color.White;
            this.btn_item.OnHoverImage = null;
            this.btn_item.OnPressedColor = System.Drawing.Color.Black;
            this.btn_item.Size = new System.Drawing.Size(160, 42);
            this.btn_item.TabIndex = 2;
            this.btn_item.Text = "Menu items";
            this.btn_item.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btn_item.Click += new System.EventHandler(this.btn_item_Click);
            // 
            // btn_customer
            // 
            this.btn_customer.AnimationHoverSpeed = 0.07F;
            this.btn_customer.AnimationSpeed = 0.03F;
            this.btn_customer.BaseColor = System.Drawing.Color.Transparent;
            this.btn_customer.BorderColor = System.Drawing.Color.Black;
            this.btn_customer.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btn_customer.FocusedColor = System.Drawing.Color.Empty;
            this.btn_customer.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_customer.ForeColor = System.Drawing.Color.White;
            this.btn_customer.Image = ((System.Drawing.Image)(resources.GetObject("btn_customer.Image")));
            this.btn_customer.ImageSize = new System.Drawing.Size(20, 20);
            this.btn_customer.Location = new System.Drawing.Point(21, 215);
            this.btn_customer.Name = "btn_customer";
            this.btn_customer.OnHoverBaseColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btn_customer.OnHoverBorderColor = System.Drawing.Color.Black;
            this.btn_customer.OnHoverForeColor = System.Drawing.Color.White;
            this.btn_customer.OnHoverImage = null;
            this.btn_customer.OnPressedColor = System.Drawing.Color.Black;
            this.btn_customer.Size = new System.Drawing.Size(160, 42);
            this.btn_customer.TabIndex = 2;
            this.btn_customer.Text = "Customer";
            this.btn_customer.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btn_customer.Click += new System.EventHandler(this.btn_customer_Click);
            // 
            // gunaPictureBox1
            // 
            this.gunaPictureBox1.BaseColor = System.Drawing.Color.White;
            this.gunaPictureBox1.Image = global::quanlynhahang.Properties.Resources.restaurant;
            this.gunaPictureBox1.Location = new System.Drawing.Point(38, 13);
            this.gunaPictureBox1.Name = "gunaPictureBox1";
            this.gunaPictureBox1.Size = new System.Drawing.Size(120, 120);
            this.gunaPictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gunaPictureBox1.TabIndex = 0;
            this.gunaPictureBox1.TabStop = false;
            // 
            // gunaPictureBox2
            // 
            this.gunaPictureBox2.BaseColor = System.Drawing.Color.White;
            this.gunaPictureBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gunaPictureBox2.Image = global::quanlynhahang.Properties.Resources.hinh_nen_powerpoint_slide_mo_dau_congngheaz_5_1024x576;
            this.gunaPictureBox2.Location = new System.Drawing.Point(0, 0);
            this.gunaPictureBox2.Name = "gunaPictureBox2";
            this.gunaPictureBox2.Size = new System.Drawing.Size(952, 620);
            this.gunaPictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.gunaPictureBox2.TabIndex = 0;
            this.gunaPictureBox2.TabStop = false;
            // 
            // gunaElipse1
            // 
            this.gunaElipse1.Radius = 30;
            this.gunaElipse1.TargetControl = this;
            // 
            // gunaAnimateWindow1
            // 
            this.gunaAnimateWindow1.AnimationType = Guna.UI.WinForms.GunaAnimateWindow.AnimateWindowType.AW_CENTER;
            this.gunaAnimateWindow1.Interval = 100;
            this.gunaAnimateWindow1.TargetControl = null;
            // 
            // Menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1152, 668);
            this.Controls.Add(this.gunaPanel3);
            this.Controls.Add(this.gunaPanel2);
            this.Controls.Add(this.centerpanel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Menu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Menu";
            this.centerpanel.ResumeLayout(false);
            this.gunaPanel2.ResumeLayout(false);
            this.gunaPanel2.PerformLayout();
            this.gunaPanel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI.WinForms.GunaPanel centerpanel;
        private Guna.UI.WinForms.GunaPanel gunaPanel2;
        private Guna.UI.WinForms.GunaPictureBox gunaPictureBox1;
        private Guna.UI.WinForms.GunaPanel gunaPanel3;
        private Guna.UI.WinForms.GunaControlBox gunaControlBox3;
        private Guna.UI.WinForms.GunaControlBox gunaControlBox2;
        private Guna.UI.WinForms.GunaControlBox gunaControlBox1;
        private Guna.UI.WinForms.GunaButton btn_payment;
        private Guna.UI.WinForms.GunaButton btn_pos;
        private Guna.UI.WinForms.GunaButton btn_order;
        private Guna.UI.WinForms.GunaButton btn_table;
        private Guna.UI.WinForms.GunaButton btn_item;
        private Guna.UI.WinForms.GunaButton btn_customer;
        private Guna.UI.WinForms.GunaLabel gunaLabel1;
        private Guna.UI.WinForms.GunaPictureBox gunaPictureBox2;
        private Guna.UI.WinForms.GunaElipse gunaElipse1;
        private Guna.UI.WinForms.GunaAnimateWindow gunaAnimateWindow1;
    }
}